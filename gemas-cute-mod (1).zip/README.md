# Gemas Cute (Forge 1.20.1)

Trece minerales pastel con forma monísima, cada uno con su función y su rareza. Y por las minas pasean los **gemoides**: criaturas-gema pacíficas, como en Steven Universe.

## Las 13 gemas
| Gema | Forma | Dónde (Y) / rareza | Función |
|---|---|---|---|
| Pinkita | corazón | -16 a 96, muy común | Herramientas completas; la espada suelta corazoncitos |
| Mentita | trébol | -32 a 64, común | Polvo de Mentita: harina de hueso |
| Limonita | limón | -24 a 72, común | Limonada: quita efectos malos |
| Chocolita | galleta | -56 a 40, común | Barra de chocolita: comida potente |
| Jellita | gominola | -48 a 32, poco común | Bloque que rebota |
| Coralita | concha | Solo océanos y playas (Y 20 a 70), poco común | Concha: respirar bajo el agua + gracia del delfín |
| Estrellita | estrella | -64 a 16, rara | Lámpara de luz máxima |
| Perlita | perla | -40 a 24, rara | Perla curativa: +5 corazones |
| Cielita | nube | 90 a 230, rara (montañas) | Báculo: te lanza al cielo |
| Lunita | luna | -64 a -8, muy rara | Varita de salto lunar (teletransporte corto) |
| Solita | sol | 64 a 180, muy rara (montañas) | Amuleto: resistencia al fuego y prisa |
| Berrita | frambuesa | -64 a -24, la más rara | Corazón: vida extra, regeneración y absorción |
| Iridita | arcoíris | -64 a -36, ultra rara | Amuleto arcoíris: suerte y velocidad |

## Gemoides
Viven bajo tierra (cuevas y minas) y **no son hostiles**. La gema que llevan depende de la altura y del bioma donde aparecen, igual que las menas. Brillan en la oscuridad.
- **Hacerse amigos:** dale su gema (solo acepta la suya) con clic derecho. Si les das una gema equivocada no pasa nada.
- **Una vez amigo:** te sigue; clic derecho con la mano vacía = se queda quieto / te sigue otra vez; agachado + clic = abrazo. Con su gema en la mano lo curas del todo. Defiende a su dueño de monstruos.
- **Si caen:** dejan su gema.
- Hay un huevo de gemoide por cada gema en la pestaña creativa.

| Gemoide | Característica (si es tu amigo y está a menos de 8 bloques) |
|---|---|
| Pinkita | Aura de regeneración |
| Mentita | Jardinera: hace crecer plantas cercanas |
| Limonita | Purificadora: quita efectos malos |
| Chocolita | Golosa: te quita el hambre poco a poco y deja galletas |
| Jellita | Saltarina: bota siempre, no sufre caídas y te da salto mejorado |
| Coralita | Marinera: respiras bajo el agua y nadas mejor; ella también |
| Estrellita | Brillante: se ve a través de las paredes, y te da visión nocturna |
| Perlita | Sanadora: te cura de golpe cuando estás muy herido |
| Cielita | Veloz y ligera: te da velocidad y no sufre caídas |
| Lunita | Soñadora: caída lenta para ti, y no sufre caídas |
| Solita | Cálida: inmune al fuego y te da resistencia al fuego |
| Berrita | Valiente: más fuerte y te da fuerza |
| Iridita | Afortunada: te da suerte y de vez en cuando suelta una gema al azar |

Herramienta necesaria: Pinkita, Mentita, Jellita, Limonita, Coralita y Chocolita con pico de piedra; Estrellita, Lunita, Solita, Cielita y Perlita con hierro; Berrita e Iridita con diamante.

## Compilar con GitHub (sin descomprimir)
1. Sube el zip del mod tal cual a la raíz de un repositorio.
2. Crea a mano `.github/workflows/build.yml` con el archivo que acompaña al zip (la carpeta `.github` es oculta y no se sube arrastrando).
3. Actions > último workflow > Artifacts > `gemas-cute-jar`.
