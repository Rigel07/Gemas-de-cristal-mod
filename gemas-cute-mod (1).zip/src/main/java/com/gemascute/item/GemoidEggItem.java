package com.gemascute.item;

import com.gemascute.entity.GemType;
import com.gemascute.entity.GemoidEntity;
import com.gemascute.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Huevo de gemoide: hace aparecer un gemoide de una gema concreta. */
public class GemoidEggItem extends Item {
    private final GemType type;

    public GemoidEggItem(GemType type, Properties properties) {
        super(properties);
        this.type = type;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (!(level instanceof ServerLevel server)) {
            return InteractionResult.SUCCESS;
        }
        BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
        GemoidEntity gemoid = ModEntities.GEMOID.get().create(server);
        if (gemoid == null) {
            return InteractionResult.FAIL;
        }
        gemoid.setGemType(this.type);
        gemoid.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, server.random.nextFloat() * 360.0F, 0.0F);
        gemoid.finalizeSpawn(server, server.getCurrentDifficultyAt(pos), MobSpawnType.SPAWN_EGG, null, null);
        server.addFreshEntity(gemoid);
        if (context.getPlayer() == null || !context.getPlayer().getAbilities().instabuild) {
            context.getItemInHand().shrink(1);
        }
        return InteractionResult.CONSUME;
    }
}
