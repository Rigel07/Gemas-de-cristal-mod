package com.gemascute.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;

/** Espada de Pinkita: al golpear salen corazoncitos. */
public class PinkitaSwordItem extends SwordItem {
    public PinkitaSwordItem(Tier tier, int damage, float speed, Properties properties) {
        super(tier, damage, speed, properties);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (target.level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.HEART, target.getX(), target.getEyeY(), target.getZ(),
                    5, 0.4D, 0.3D, 0.4D, 0.05D);
        }
        return super.hurtEnemy(stack, target, attacker);
    }
}
