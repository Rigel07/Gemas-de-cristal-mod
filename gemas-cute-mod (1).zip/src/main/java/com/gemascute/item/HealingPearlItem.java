package com.gemascute.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Perla de Perlita: clic derecho = te cura 5 corazones (pocos usos, con espera). */
public class HealingPearlItem extends Item {
    public HealingPearlItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            if (player.getHealth() >= player.getMaxHealth()) {
                player.displayClientMessage(Component.translatable("message.gemascute.pearl_full"), true);
                return InteractionResultHolder.fail(stack);
            }
            player.heal(10.0F);
            level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                    SoundSource.PLAYERS, 1.0F, 1.0F);
            if (level instanceof ServerLevel server) {
                server.sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + 1.2D, player.getZ(),
                        8, 0.4D, 0.4D, 0.4D, 0.05D);
            }
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            player.getCooldowns().addCooldown(this, 200);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
