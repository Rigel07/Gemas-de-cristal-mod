package com.gemascute.client;

import com.gemascute.entity.GemoidEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;

/** Las gemas del gemoide brillan en la oscuridad (como los ojos de una arana). */
public class GemGlowLayer extends RenderLayer<GemoidEntity, GemoidModel<GemoidEntity>> {
    public GemGlowLayer(RenderLayerParent<GemoidEntity, GemoidModel<GemoidEntity>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, GemoidEntity entity,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (entity.isInvisible()) {
            return;
        }
        VertexConsumer consumer = buffer.getBuffer(RenderType.eyes(entity.getGemType().glowTexture()));
        this.getParentModel().renderToBuffer(poseStack, consumer, 15728640, OverlayTexture.NO_OVERLAY,
                1.0F, 1.0F, 1.0F, 1.0F);
    }
}
