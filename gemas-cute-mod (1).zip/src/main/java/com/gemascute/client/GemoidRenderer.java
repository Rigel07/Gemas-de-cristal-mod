package com.gemascute.client;

import com.gemascute.entity.GemoidEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class GemoidRenderer extends MobRenderer<GemoidEntity, GemoidModel<GemoidEntity>> {
    public GemoidRenderer(EntityRendererProvider.Context context) {
        super(context, new GemoidModel<>(context.bakeLayer(GemoidModel.LAYER_LOCATION)), 0.35F);
        this.addLayer(new GemGlowLayer(this));
    }

    @Override
    public ResourceLocation getTextureLocation(GemoidEntity entity) {
        return entity.getGemType().texture();
    }
}
