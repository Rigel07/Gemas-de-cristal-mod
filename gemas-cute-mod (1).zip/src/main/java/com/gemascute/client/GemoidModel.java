package com.gemascute.client;

import com.gemascute.GemasCuteMod;
import com.gemascute.entity.GemoidEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Modelo chibi del gemoide: cabeza grande con pelo, cuerpo pequenito. Textura 64x32. */
public class GemoidModel<T extends GemoidEntity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(GemasCuteMod.MODID, "gemoid"), "main");

    private final ModelPart root;
    private final ModelPart model;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    public GemoidModel(ModelPart root) {
        this.root = root;
        this.model = root.getChild("model");
        this.head = this.model.getChild("head");
        this.rightArm = this.model.getChild("right_arm");
        this.leftArm = this.model.getChild("left_arm");
        this.rightLeg = this.model.getChild("right_leg");
        this.leftLeg = this.model.getChild("left_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition model = root.addOrReplaceChild("model", CubeListBuilder.create(), PartPose.ZERO);

        model.addOrReplaceChild("head", CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F)
                        .texOffs(32, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.5F)),
                PartPose.offset(0.0F, 12.0F, 0.0F));
        model.addOrReplaceChild("body", CubeListBuilder.create()
                        .texOffs(16, 16).addBox(-3.0F, -7.0F, -2.0F, 6.0F, 7.0F, 4.0F),
                PartPose.offset(0.0F, 19.0F, 0.0F));
        model.addOrReplaceChild("right_arm", CubeListBuilder.create()
                        .texOffs(40, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                PartPose.offset(-4.0F, 13.0F, 0.0F));
        model.addOrReplaceChild("left_arm", CubeListBuilder.create()
                        .texOffs(40, 16).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                PartPose.offset(4.0F, 13.0F, 0.0F));
        model.addOrReplaceChild("right_leg", CubeListBuilder.create()
                        .texOffs(0, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                PartPose.offset(-1.5F, 19.0F, 0.0F));
        model.addOrReplaceChild("left_leg", CubeListBuilder.create()
                        .texOffs(0, 16).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                PartPose.offset(1.5F, 19.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        this.model.y = 0.0F;
        this.head.yRot = netHeadYaw * ((float) Math.PI / 180F);
        this.head.xRot = headPitch * ((float) Math.PI / 180F);

        float swing = limbSwing * 0.6662F;
        this.rightArm.xRot = Mth.cos(swing + (float) Math.PI) * 1.2F * limbSwingAmount;
        this.leftArm.xRot = Mth.cos(swing) * 1.2F * limbSwingAmount;
        this.rightLeg.xRot = Mth.cos(swing) * 1.4F * limbSwingAmount;
        this.leftLeg.xRot = Mth.cos(swing + (float) Math.PI) * 1.4F * limbSwingAmount;

        // Balanceo suave de brazos en reposo
        this.rightArm.zRot = 0.06F + Mth.sin(ageInTicks * 0.067F) * 0.05F;
        this.leftArm.zRot = -0.06F - Mth.sin(ageInTicks * 0.067F) * 0.05F;

        if (entity.isInSittingPose()) {
            this.model.y = 4.0F;
            this.rightLeg.xRot = -1.45F;
            this.leftLeg.xRot = -1.45F;
            this.rightArm.xRot = -0.3F;
            this.leftArm.xRot = -0.3F;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
