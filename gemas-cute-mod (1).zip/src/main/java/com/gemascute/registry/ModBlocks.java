package com.gemascute.registry;

import com.gemascute.GemasCuteMod;
import com.gemascute.block.JellyBlock;
import java.util.function.Supplier;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, GemasCuteMod.MODID);
    /** Los items de bloque van aparte para no mezclar registros. */
    public static final DeferredRegister<Item> BLOCK_ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, GemasCuteMod.MODID);

    /** Datos de cada mineral: nombre, dureza de la mena, luz de mena, luz del bloque, experiencia, color. */
    private record Spec(String name, float hardness, int oreLight, int blockLight, int xpMin, int xpMax, MapColor color) {}

    private static final Spec[] SPECS = {
            new Spec("pinkita",    3.0F, 0, 0,  1, 3,  MapColor.COLOR_PINK),
            new Spec("mentita",    3.0F, 0, 0,  1, 3,  MapColor.EMERALD),
            new Spec("jellita",    3.0F, 0, 0,  2, 4,  MapColor.COLOR_LIGHT_BLUE),
            new Spec("estrellita", 3.5F, 6, 12, 3, 6,  MapColor.COLOR_YELLOW),
            new Spec("lunita",     4.0F, 3, 4,  4, 8,  MapColor.COLOR_PURPLE),
            new Spec("solita",     4.0F, 5, 8,  5, 9,  MapColor.COLOR_ORANGE),
            new Spec("berrita",    5.0F, 0, 0,  7, 12, MapColor.CRIMSON_NYLIUM),
            new Spec("cielita",    3.5F, 4, 0,  3, 6,  MapColor.COLOR_CYAN),
            new Spec("limonita",   3.0F, 0, 0,  1, 3,  MapColor.COLOR_LIGHT_GREEN),
            new Spec("coralita",   3.0F, 0, 0,  1, 4,  MapColor.CRIMSON_HYPHAE),
            new Spec("perlita",    3.5F, 3, 0,  3, 6,  MapColor.QUARTZ),
            new Spec("chocolita",  3.0F, 0, 0,  1, 3,  MapColor.TERRACOTTA_BROWN),
            new Spec("iridita",    6.0F, 7, 6,  8, 14, MapColor.COLOR_MAGENTA),
    };

    /** Lampara brillante hecha con Estrellita. */
    public static final RegistryObject<Block> ESTRELLITA_LAMP;

    static {
        for (Spec spec : SPECS) {
            ore(spec.name() + "_ore", false, spec);
            ore("deepslate_" + spec.name() + "_ore", true, spec);
            if (spec.name().equals("jellita")) {
                // El bloque de Jellita rebota como una gominola.
                block("jellita_block", () -> new JellyBlock(BlockBehaviour.Properties.of()
                        .mapColor(MapColor.COLOR_LIGHT_BLUE)
                        .strength(1.0F)
                        .sound(SoundType.SLIME_BLOCK)));
            } else {
                block(spec.name() + "_block", () -> new Block(BlockBehaviour.Properties.of()
                        .mapColor(spec.color())
                        .strength(spec.hardness() + 1.0F, 6.0F)
                        .requiresCorrectToolForDrops()
                        .sound(SoundType.AMETHYST)
                        .lightLevel(state -> spec.blockLight())));
            }
        }
        ESTRELLITA_LAMP = block("estrellita_lamp", () -> new Block(BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_YELLOW)
                .strength(1.5F)
                .sound(SoundType.GLASS)
                .lightLevel(state -> 15)));
    }

    private static void ore(String name, boolean deepslate, Spec spec) {
        block(name, () -> new DropExperienceBlock(BlockBehaviour.Properties.of()
                .mapColor(spec.color())
                .strength(deepslate ? spec.hardness() + 1.5F : spec.hardness(), 3.0F)
                .requiresCorrectToolForDrops()
                .sound(deepslate ? SoundType.DEEPSLATE : SoundType.STONE)
                .lightLevel(state -> spec.oreLight()),
                UniformInt.of(spec.xpMin(), spec.xpMax())));
    }

    private static RegistryObject<Block> block(String name, Supplier<Block> supplier) {
        RegistryObject<Block> object = BLOCKS.register(name, supplier);
        BLOCK_ITEMS.register(name, () -> new BlockItem(object.get(), new Item.Properties()));
        return object;
    }
}
