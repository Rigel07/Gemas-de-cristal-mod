package com.gemascute.registry;

import com.gemascute.GemasCuteMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;

public class ModTags {
    /** Las 13 gemas. Los gemoides salvajes siguen a quien lleva una en la mano. */
    public static final TagKey<Item> GEMS =
            TagKey.create(Registries.ITEM, new ResourceLocation(GemasCuteMod.MODID, "gems"));
}
