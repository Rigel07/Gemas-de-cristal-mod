package com.gemascute.registry;

import com.gemascute.GemasCuteMod;
import com.gemascute.entity.GemoidEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, GemasCuteMod.MODID);

    public static final RegistryObject<EntityType<GemoidEntity>> GEMOID = ENTITIES.register("gemoid",
            () -> EntityType.Builder.<GemoidEntity>of(GemoidEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.25F)
                    .clientTrackingRange(8)
                    .build("gemoid"));
}
