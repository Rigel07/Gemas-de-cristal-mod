package com.gemascute.registry;

import com.gemascute.GemasCuteMod;
import com.gemascute.entity.GemType;
import com.gemascute.item.CharmItem;
import com.gemascute.item.CloudStaffItem;
import com.gemascute.item.GemoidEggItem;
import com.gemascute.item.HealingPearlItem;
import com.gemascute.item.LimonadeItem;
import com.gemascute.item.LunitaWandItem;
import com.gemascute.item.PinkitaSwordItem;
import java.util.List;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ShovelItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, GemasCuteMod.MODID);

    // ---- Las 13 gemas ----
    public static final RegistryObject<Item> PINKITA = gem("pinkita", Rarity.COMMON);
    public static final RegistryObject<Item> MENTITA = gem("mentita", Rarity.COMMON);
    public static final RegistryObject<Item> JELLITA = gem("jellita", Rarity.UNCOMMON);
    public static final RegistryObject<Item> ESTRELLITA = gem("estrellita", Rarity.UNCOMMON);
    public static final RegistryObject<Item> LUNITA = gem("lunita", Rarity.RARE);
    public static final RegistryObject<Item> SOLITA = gem("solita", Rarity.RARE);
    public static final RegistryObject<Item> BERRITA = gem("berrita", Rarity.EPIC);
    public static final RegistryObject<Item> CIELITA = gem("cielita", Rarity.RARE);
    public static final RegistryObject<Item> LIMONITA = gem("limonita", Rarity.COMMON);
    public static final RegistryObject<Item> CORALITA = gem("coralita", Rarity.UNCOMMON);
    public static final RegistryObject<Item> PERLITA = gem("perlita", Rarity.RARE);
    public static final RegistryObject<Item> CHOCOLITA = gem("chocolita", Rarity.COMMON);
    public static final RegistryObject<Item> IRIDITA = gem("iridita", Rarity.EPIC);

    // ---- Mentita: fertilizante (funciona como harina de hueso) ----
    public static final RegistryObject<Item> MENTITA_DUST = ITEMS.register("mentita_dust",
            () -> new BoneMealItem(new Item.Properties()));

    // ---- Pinkita: herramientas ----
    public static final RegistryObject<Item> PINKITA_SWORD = ITEMS.register("pinkita_sword",
            () -> new PinkitaSwordItem(ModTiers.PINKITA, 3, -2.4F, new Item.Properties()));
    public static final RegistryObject<Item> PINKITA_PICKAXE = ITEMS.register("pinkita_pickaxe",
            () -> new PickaxeItem(ModTiers.PINKITA, 1, -2.8F, new Item.Properties()));
    public static final RegistryObject<Item> PINKITA_AXE = ITEMS.register("pinkita_axe",
            () -> new AxeItem(ModTiers.PINKITA, 5.0F, -3.0F, new Item.Properties()));
    public static final RegistryObject<Item> PINKITA_SHOVEL = ITEMS.register("pinkita_shovel",
            () -> new ShovelItem(ModTiers.PINKITA, 1.5F, -3.0F, new Item.Properties()));
    public static final RegistryObject<Item> PINKITA_HOE = ITEMS.register("pinkita_hoe",
            () -> new HoeItem(ModTiers.PINKITA, -1, -1.0F, new Item.Properties()));

    // ---- Lunita: varita de salto lunar ----
    public static final RegistryObject<Item> LUNITA_WAND = ITEMS.register("lunita_wand",
            () -> new LunitaWandItem(new Item.Properties().durability(60).rarity(Rarity.RARE)));

    // ---- Solita: amuleto (fuego + prisa) ----
    public static final RegistryObject<Item> SOLITA_AMULET = ITEMS.register("solita_amulet",
            () -> new CharmItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE), () -> List.of(
                    new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 100, 0, true, false, true),
                    new MobEffectInstance(MobEffects.DIG_SPEED, 100, 0, true, false, true))));

    // ---- Berrita: corazon de vida extra ----
    public static final RegistryObject<Item> BERRITA_HEART = ITEMS.register("berrita_heart",
            () -> new Item(new Item.Properties().rarity(Rarity.EPIC).food(new FoodProperties.Builder()
                    .nutrition(6)
                    .saturationMod(1.0F)
                    .alwaysEat()
                    .effect(() -> new MobEffectInstance(MobEffects.HEALTH_BOOST, 6000, 2), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 200, 1), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 2400, 1), 1.0F)
                    .build())));

    // ---- Cielita: baculo que te lanza al cielo ----
    public static final RegistryObject<Item> CIELITA_STAFF = ITEMS.register("cielita_staff",
            () -> new CloudStaffItem(new Item.Properties().durability(40).rarity(Rarity.RARE)));

    // ---- Limonita: limonada que limpia efectos malos ----
    public static final RegistryObject<Item> LIMONADE = ITEMS.register("limonade",
            () -> new LimonadeItem(new Item.Properties().stacksTo(16)));

    // ---- Coralita: concha marina (respirar bajo el agua) ----
    public static final RegistryObject<Item> CORALITA_SHELL = ITEMS.register("coralita_shell",
            () -> new CharmItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE), () -> List.of(
                    new MobEffectInstance(MobEffects.WATER_BREATHING, 100, 0, true, false, true),
                    new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 100, 0, true, false, true))));

    // ---- Perlita: perla curativa ----
    public static final RegistryObject<Item> PERLITA_PEARL = ITEMS.register("perlita_pearl",
            () -> new HealingPearlItem(new Item.Properties().durability(6).rarity(Rarity.RARE)));

    // ---- Chocolita: barra de chocolate ----
    public static final RegistryObject<Item> CHOCOLITA_BAR = ITEMS.register("chocolita_bar",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(8)
                    .saturationMod(1.2F)
                    .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 0), 1.0F)
                    .build())));

    // ---- Iridita: amuleto arcoiris (suerte + velocidad) ----
    public static final RegistryObject<Item> IRIDITA_AMULET = ITEMS.register("iridita_amulet",
            () -> new CharmItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC), () -> List.of(
                    new MobEffectInstance(MobEffects.LUCK, 100, 1, true, false, true),
                    new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 0, true, false, true))));

    // ---- Huevos de gemoide (uno por gema) ----
    static {
        for (GemType type : GemType.values()) {
            ITEMS.register(type.id() + "_gemoid_egg", () -> new GemoidEggItem(type, new Item.Properties()));
        }
    }

    private static RegistryObject<Item> gem(String name, Rarity rarity) {
        return ITEMS.register(name, () -> new Item(new Item.Properties().rarity(rarity)));
    }
}
