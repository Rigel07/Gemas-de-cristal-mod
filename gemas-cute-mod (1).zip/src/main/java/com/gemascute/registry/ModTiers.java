package com.gemascute.registry;

import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.common.ForgeTier;

public class ModTiers {
    /** Herramientas de Pinkita: un poquito mejores que el hierro, y muy monas. */
    public static final ForgeTier PINKITA = new ForgeTier(2, 450, 7.0F, 2.5F, 20,
            BlockTags.NEEDS_IRON_TOOL, () -> Ingredient.of(ModItems.PINKITA.get()));
}
