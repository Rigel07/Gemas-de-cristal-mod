package com.gemascute.entity;

import com.gemascute.GemasCuteMod;
import com.gemascute.registry.ModItems;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BiomeTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.LevelAccessor;

/**
 * Las 13 gemas. Cada gemoide lleva una y su gema decide su caracteristica.
 * Los suppliers son perezosos a proposito para no crear ciclos de carga con ModItems.
 */
public enum GemType {
    PINKITA("pinkita", () -> ModItems.PINKITA.get(), 14, -30, 100),
    MENTITA("mentita", () -> ModItems.MENTITA.get(), 12, -40, 70),
    LIMONITA("limonita", () -> ModItems.LIMONITA.get(), 10, -30, 80),
    CHOCOLITA("chocolita", () -> ModItems.CHOCOLITA.get(), 9, -60, 50),
    JELLITA("jellita", () -> ModItems.JELLITA.get(), 8, -50, 40),
    ESTRELLITA("estrellita", () -> ModItems.ESTRELLITA.get(), 6, -64, 20),
    PERLITA("perlita", () -> ModItems.PERLITA.get(), 5, -50, 30),
    CORALITA("coralita", () -> ModItems.CORALITA.get(), 6, -20, 80),
    CIELITA("cielita", () -> ModItems.CIELITA.get(), 4, 90, 220),
    LUNITA("lunita", () -> ModItems.LUNITA.get(), 3, -64, 0),
    SOLITA("solita", () -> ModItems.SOLITA.get(), 3, 64, 200),
    BERRITA("berrita", () -> ModItems.BERRITA.get(), 2, -64, -20),
    IRIDITA("iridita", () -> ModItems.IRIDITA.get(), 1, -64, -30);

    private final String id;
    private final Supplier<Item> gem;
    private final int weight;
    private final int minY;
    private final int maxY;
    private final ResourceLocation texture;
    private final ResourceLocation glowTexture;

    GemType(String id, Supplier<Item> gem, int weight, int minY, int maxY) {
        this.id = id;
        this.gem = gem;
        this.weight = weight;
        this.minY = minY;
        this.maxY = maxY;
        this.texture = new ResourceLocation(GemasCuteMod.MODID, "textures/entity/gemoid_" + id + ".png");
        this.glowTexture = new ResourceLocation(GemasCuteMod.MODID, "textures/entity/gemoid_" + id + "_glow.png");
    }

    public String id() { return this.id; }
    public Item gem() { return this.gem.get(); }
    public ResourceLocation texture() { return this.texture; }
    public ResourceLocation glowTexture() { return this.glowTexture; }

    public static GemType byIndex(int index) {
        GemType[] values = values();
        if (index < 0 || index >= values.length) {
            return PINKITA;
        }
        return values[index];
    }

    public static GemType byName(String name) {
        for (GemType type : values()) {
            if (type.id.equals(name)) {
                return type;
            }
        }
        return null;
    }

    /** Elige una gema segun la altura y el bioma donde aparece (igual que las menas). */
    public static GemType pick(LevelAccessor level, BlockPos pos, RandomSource random) {
        boolean water = level.getBiome(pos).is(BiomeTags.IS_OCEAN)
                || level.getBiome(pos).is(BiomeTags.IS_BEACH)
                || level.getBiome(pos).is(BiomeTags.IS_RIVER);
        int total = 0;
        int[] weights = new int[values().length];
        for (GemType type : values()) {
            int w = type.weight;
            if (pos.getY() < type.minY || pos.getY() > type.maxY) {
                w = 0;
            }
            if (type == CORALITA && !water) {
                w = 0;
            }
            weights[type.ordinal()] = w;
            total += w;
        }
        if (total <= 0) {
            return PINKITA;
        }
        int roll = random.nextInt(total);
        for (GemType type : values()) {
            roll -= weights[type.ordinal()];
            if (roll < 0) {
                return type;
            }
        }
        return PINKITA;
    }
}
