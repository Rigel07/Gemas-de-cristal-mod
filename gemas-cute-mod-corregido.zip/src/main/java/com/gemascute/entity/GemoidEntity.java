package com.gemascute.entity;

import com.gemascute.registry.ModTags;
import java.util.ArrayList;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.ForgeEventFactory;

/**
 * Gemoide: criatura-gema pacifica que vive en las minas.
 * Se hace amiga si le das SU gema, y entonces su gema le da una caracteristica propia
 * (un aura que te ayuda, o una habilidad especial).
 */
public class GemoidEntity extends TamableAnimal {
    private static final EntityDataAccessor<Integer> DATA_GEM =
            SynchedEntityData.defineId(GemoidEntity.class, EntityDataSerializers.INT);

    private int specialTimer = 4800;
    private int healCooldown = 0;

    public GemoidEntity(EntityType<? extends GemoidEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    /** Regla de aparicion: bajo tierra (sin cielo encima), sobre suelo solido. */
    public static boolean checkGemoidSpawnRules(EntityType<GemoidEntity> type, ServerLevelAccessor level,
                                                MobSpawnType reason, BlockPos pos, RandomSource random) {
        return pos.getY() <= 200
                && !level.canSeeSky(pos)
                && Mob.checkMobSpawnRules(type, level, reason, pos, random);
    }

    // ------------------------------------------------------------------ Gema

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_GEM, -1);
    }

    public boolean hasGemType() {
        return this.entityData.get(DATA_GEM) >= 0;
    }

    public GemType getGemType() {
        return GemType.byIndex(this.entityData.get(DATA_GEM));
    }

    public void setGemType(GemType type) {
        this.entityData.set(DATA_GEM, type.ordinal());
        this.applyStats();
        this.setGlowingTag(type == GemType.ESTRELLITA);
    }

    private void applyStats() {
        boolean berrita = this.getGemType() == GemType.BERRITA;
        this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(berrita ? 30.0D : 20.0D);
        this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(berrita ? 6.0D : 3.0D);
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        if (!this.hasGemType()) {
            this.setGemType(GemType.pick(level, this.blockPosition(), this.getRandom()));
        }
        this.setHealth(this.getMaxHealth());
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    @Override
    public Component getTypeName() {
        return Component.translatable("entity.gemascute.gemoid." + this.getGemType().id());
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("Gem", this.getGemType().id());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        GemType type = GemType.byName(tag.getString("Gem"));
        if (type != null) {
            this.setGemType(type);
        }
        if (tag.contains("Health", 99)) {
            this.setHealth(tag.getFloat("Health"));
        }
    }

    // -------------------------------------------------------------------- IA

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(3, new PanicGoal(this, 1.4D) {
            @Override
            public boolean canUse() {
                return !GemoidEntity.this.isTame() && super.canUse();
            }
        });
        this.goalSelector.addGoal(4, new MeleeAttackGoal(this, 1.2D, true));
        this.goalSelector.addGoal(5, new FollowOwnerGoal(this, 1.1D, 6.0F, 2.0F, false));
        this.goalSelector.addGoal(6, new TemptGoal(this, 1.0D, Ingredient.of(ModTags.GEMS), false) {
            @Override
            public boolean canUse() {
                return !GemoidEntity.this.isTame() && super.canUse();
            }
        });
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
    }

    @Override
    public boolean wantsToAttack(LivingEntity target, LivingEntity owner) {
        if (target instanceof net.minecraft.world.entity.monster.Creeper
                || target instanceof net.minecraft.world.entity.monster.Ghast) {
            return false;
        }
        if (target instanceof GemoidEntity other) {
            return !other.isTame() || other.getOwner() != owner;
        }
        if (target instanceof Player targetPlayer && owner instanceof Player ownerPlayer
                && !ownerPlayer.canHarmPlayer(targetPlayer)) {
            return false;
        }
        if (target instanceof TamableAnimal tamable) {
            return !tamable.isTame();
        }
        return true;
    }

    // ------------------------------------------------------- Interaccion

    @Override
    public boolean isFood(ItemStack stack) {
        return stack.is(this.getGemType().gem());
    }

    @Override
    public boolean canFallInLove() {
        return false;
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob mate) {
        return null;
    }

    private void tell(Player player, String key, Object... args) {
        player.displayClientMessage(Component.translatable(key, args), true);
    }

    @Override
    public void tame(Player player) {
        super.tame(player);
        this.setPersistenceRequired();
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        boolean client = this.level().isClientSide;
        GemType type = this.getGemType();

        // --- Salvaje: se hace amigo si le das SU gema ---
        if (!this.isTame()) {
            if (stack.is(ModTags.GEMS)) {
                if (stack.is(type.gem())) {
                    if (!client) {
                        if (!player.getAbilities().instabuild) {
                            stack.shrink(1);
                        }
                        if (!ForgeEventFactory.onAnimalTame(this, player)) {
                            this.tame(player);
                            this.getNavigation().stop();
                            this.setTarget(null);
                            this.setOrderedToSit(false);
                            this.setInSittingPose(false);
                            this.setHealth(this.getMaxHealth());
                            this.level().broadcastEntityEvent(this, (byte) 7);
                            this.playSound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F, 1.6F);
                            this.tell(player, "message.gemascute.tamed", this.getTypeName());
                        } else {
                            this.level().broadcastEntityEvent(this, (byte) 6);
                        }
                    }
                    return InteractionResult.sidedSuccess(client);
                }
                if (!client) {
                    this.tell(player, "message.gemascute.not_its_gem");
                }
                return InteractionResult.CONSUME;
            }
            return InteractionResult.PASS;
        }

        // --- Amigo: solo obedece a su duenio ---
        if (!this.isOwnedBy(player)) {
            return InteractionResult.PASS;
        }

        // Su gema: la cura del todo
        if (stack.is(type.gem())) {
            if (this.getHealth() < this.getMaxHealth()) {
                if (!client) {
                    if (!player.getAbilities().instabuild) {
                        stack.shrink(1);
                    }
                    this.heal(this.getMaxHealth());
                    this.level().broadcastEntityEvent(this, (byte) 7);
                    this.playSound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F, 1.4F);
                }
                return InteractionResult.sidedSuccess(client);
            }
            return InteractionResult.CONSUME;
        }

        // Agachado + mano vacia: abrazo
        if (stack.isEmpty() && player.isShiftKeyDown()) {
            if (!client) {
                this.level().broadcastEntityEvent(this, (byte) 7);
                this.heal(1.0F);
                this.playSound(SoundEvents.AMETHYST_BLOCK_CHIME, 0.8F, 1.9F);
            }
            return InteractionResult.sidedSuccess(client);
        }

        // Clic normal: seguir <-> quieto
        if (!client) {
            boolean sit = !this.isOrderedToSit();
            this.setOrderedToSit(sit);
            this.getNavigation().stop();
            this.setTarget(null);
            this.tell(player, sit ? "message.gemascute.sit" : "message.gemascute.follow");
        }
        return InteractionResult.sidedSuccess(client);
    }

    // ------------------------------------------------ Caracteristicas

    @Override
    public boolean fireImmune() {
        return this.getGemType() == GemType.SOLITA || super.fireImmune();
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        if (this.getGemType() == GemType.SOLITA && source.is(DamageTypeTags.IS_FIRE)) {
            return true;
        }
        return super.isInvulnerableTo(source);
    }

    @Override
    public boolean canBreatheUnderwater() {
        return this.getGemType() == GemType.CORALITA || super.canBreatheUnderwater();
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        GemType type = this.getGemType();
        if (type == GemType.JELLITA || type == GemType.CIELITA || type == GemType.LUNITA) {
            return false;
        }
        return super.causeFallDamage(distance, multiplier, source);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            return;
        }
        GemType type = this.getGemType();

        // Jellita bota como una gominola
        if (type == GemType.JELLITA && this.onGround() && !this.isInSittingPose() && this.random.nextInt(35) == 0) {
            this.jumpFromGround();
        }

        if (this.healCooldown > 0) {
            this.healCooldown--;
        }

        if (!this.isTame()) {
            return;
        }
        LivingEntity owner = this.getOwner();
        if (owner == null || owner.level() != this.level() || this.distanceToSqr(owner) > 64.0D) {
            return;
        }

        // Perlita: cura al duenio cuando esta herido
        if (type == GemType.PERLITA && this.tickCount % 20 == 0 && this.healCooldown <= 0
                && owner.getHealth() < owner.getMaxHealth() * 0.5F) {
            owner.heal(6.0F);
            this.healCooldown = 400;
            this.puff(owner, ParticleTypes.HEART);
        }

        // Aura de la gema (se renueva cada 5 segundos, escalonado entre gemoides)
        if (this.tickCount % 100 == this.getId() % 100) {
            this.applyAura(owner, type);
        }

        // Habilidades de regalo cada cierto tiempo
        if (type == GemType.CHOCOLITA || type == GemType.IRIDITA) {
            if (--this.specialTimer <= 0) {
                if (type == GemType.CHOCOLITA) {
                    this.spawnAtLocation(new ItemStack(Items.COOKIE, 1 + this.random.nextInt(2)));
                    this.specialTimer = 4800 + this.random.nextInt(3600);
                } else {
                    GemType[] all = GemType.values();
                    this.spawnAtLocation(new ItemStack(all[this.random.nextInt(all.length)].gem()));
                    this.specialTimer = 12000 + this.random.nextInt(6000);
                }
                this.puff(this, ParticleTypes.HAPPY_VILLAGER);
            }
        }
    }

    private void effect(LivingEntity owner, MobEffect effect, int duration, int amplifier) {
        owner.addEffect(new MobEffectInstance(effect, duration, amplifier, true, true));
    }

    private void applyAura(LivingEntity owner, GemType type) {
        switch (type) {
            case PINKITA -> this.effect(owner, MobEffects.REGENERATION, 120, 0);
            case JELLITA -> this.effect(owner, MobEffects.JUMP, 220, 0);
            case ESTRELLITA -> this.effect(owner, MobEffects.NIGHT_VISION, 400, 0);
            case LUNITA -> this.effect(owner, MobEffects.SLOW_FALLING, 220, 0);
            case SOLITA -> this.effect(owner, MobEffects.FIRE_RESISTANCE, 220, 0);
            case BERRITA -> this.effect(owner, MobEffects.DAMAGE_BOOST, 220, 0);
            case CIELITA -> this.effect(owner, MobEffects.MOVEMENT_SPEED, 220, 0);
            case IRIDITA -> this.effect(owner, MobEffects.LUCK, 220, 1);
            case CORALITA -> {
                this.effect(owner, MobEffects.WATER_BREATHING, 220, 0);
                this.effect(owner, MobEffects.DOLPHINS_GRACE, 220, 0);
            }
            case CHOCOLITA -> owner.addEffect(new MobEffectInstance(MobEffects.SATURATION, 1, 0, true, false));
            case LIMONITA -> {
                for (MobEffectInstance active : new ArrayList<>(owner.getActiveEffects())) {
                    if (active.getEffect().getCategory() == MobEffectCategory.HARMFUL) {
                        owner.removeEffect(active.getEffect());
                        this.puff(owner, ParticleTypes.HAPPY_VILLAGER);
                        break;
                    }
                }
            }
            case MENTITA -> this.tendPlants();
            default -> { }
        }
    }

    /** Mentita: hace crecer plantas cercanas, como harina de hueso. */
    private void tendPlants() {
        BlockPos base = this.blockPosition();
        for (int i = 0; i < 8; i++) {
            BlockPos pos = base.offset(this.random.nextInt(9) - 4, this.random.nextInt(3) - 1, this.random.nextInt(9) - 4);
            if (BoneMealItem.growCrop(new ItemStack(Items.BONE_MEAL), this.level(), pos)) {
                if (this.level() instanceof ServerLevel server) {
                    server.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5D, pos.getY() + 0.8D,
                            pos.getZ() + 0.5D, 6, 0.3D, 0.3D, 0.3D, 0.0D);
                }
                break;
            }
        }
    }

    private void puff(LivingEntity target, net.minecraft.core.particles.SimpleParticleType particle) {
        if (this.level() instanceof ServerLevel server) {
            server.sendParticles(particle, target.getX(), target.getY() + 1.0D, target.getZ(),
                    6, 0.4D, 0.4D, 0.4D, 0.02D);
        }
    }

    /** Al caer, un gemoide deja su gema (como en Steven Universe). */
    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        this.spawnAtLocation(new ItemStack(this.getGemType().gem()));
    }

    // ---------------------------------------------------------------- Sonidos

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.AMETHYST_BLOCK_CHIME;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.AMETHYST_BLOCK_HIT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.AMETHYST_BLOCK_BREAK;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.AMETHYST_BLOCK_STEP, 0.15F, 1.2F);
    }

    @Override
    public int getMaxSpawnClusterSize() {
        return 2;
    }
}
